

String getJSONString_fromstatus(float temp, int light);
